HashBrute
1.1.1
A md5 Encrypter and Decrypter
By Jakibah
www.Jakibah.nl

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
How to use the Encrypter

1. Start the exe.
2. Go to the Encrypter window.
3. Put a string in the input field.
4. Press start. 
5. The Encrypter will encrypt your input and copy it to your clipboard.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
How to use the Decrypter

1. Start the exe.
2. Go to the Decrypter window.
3. Put a md5 hash in the input field.
4. Press start.
5. The Decrypter will decrypt you hash and copy it to your clipboard

WARNING: The default wordlist is empty you have to download one yourself.
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
How to use a Downloaded List

1. Download a list (links below)
2. Remove the default list.lst file.
3. Put the dowloaded list in the your HashBrute folder.
4. Rename the downloaded list to "list" and make sure the file has the lst extension.

LINK: http://lmgtfy.com/?q=wordlist+for+bruteforcing  